# ProApp

Central authentication hub and module switcher.

## Features
- User authentication (email/password, Google OAuth)
- Module access control based on subscription
- Module switcher dashboard
- User profile management

## Dev
```bash
pnpm dev
# Runs on http://localhost:3000
```
