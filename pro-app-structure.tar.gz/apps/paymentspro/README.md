# PaymentsPro

Payments, invoicing, and subscription management.

## Features
- Invoice generation (PDF export)
- Czech SPAYD QR codes
- Payment tracking
- Subscription tiers
- Revenue analytics

## Dev
```bash
pnpm dev
# Runs on http://localhost:3002
```
