# CoachPro

Coaching materials, programs, and client management.

## Features
- Coaching programs management
- Session tracking
- Client management
- Material library
- Photo storage (WebP compression)

## Dev
```bash
pnpm dev
# Runs on http://localhost:3001
```
