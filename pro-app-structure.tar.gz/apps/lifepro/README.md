# LifePro

Life management, habits, and goal tracking.

## Features
- Habit tracking
- Goal management
- Daily routines
- Progress analytics
- Motivation system

## Dev
```bash
pnpm dev
# Runs on http://localhost:3004
```
