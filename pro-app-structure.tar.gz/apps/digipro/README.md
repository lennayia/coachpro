# DigiPro

Platform integrations hub (12 platforms).

## Features
- SmartEmailing, MailChimp
- Stripe, PayPal
- Kajabi, Thinkific
- Facebook, Instagram
- Integration status dashboard
- Dual-status system

## Dev
```bash
pnpm dev
# Runs on http://localhost:3003
```
