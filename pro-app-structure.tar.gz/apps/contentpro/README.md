# ContentPro

Social media management and content scheduling.

## Features
- Multi-platform posting (Facebook, Instagram, LinkedIn, X, YouTube)
- Content calendar
- AI content generation
- Post scheduling
- Analytics dashboard
- Media library

## Dev
```bash
pnpm dev
# Runs on http://localhost:3005
```
