# Pro App - Unified Ecosystem

Monorepo containing all Pro modules using Turborepo + PNPM.

## Structure

```
pro-app/
├── apps/
│   ├── proapp/          # Central auth hub & module switcher
│   ├── coachpro/        # Coaching materials & programs
│   ├── paymentspro/     # Payments & invoicing
│   ├── digipro/         # Platform integrations hub
│   ├── lifepro/         # Life management & habits
│   └── contentpro/      # Social media management
├── packages/
│   ├── ui/              # Shared UI components
│   ├── auth/            # Authentication logic
│   ├── database/        # Supabase client & types
│   ├── integrations/    # Third-party integrations
│   ├── notifications/   # Notification system
│   └── utils/           # Shared utilities
└── turbo.json           # Turborepo configuration
```

## Tech Stack

- **Frontend:** React 18 + Vite + Material-UI v6
- **Backend:** Supabase (PostgreSQL + Auth + Storage + Edge Functions)
- **Monorepo:** Turborepo + PNPM workspaces
- **Hosting:** Vercel (all frontends)

## Getting Started

```bash
# Install dependencies
pnpm install

# Start all apps in dev mode
pnpm dev

# Build all apps
pnpm build

# Lint all apps
pnpm lint
```

## Module Access

Users authenticate via ProApp and access modules based on their subscription tier:
- **Free:** ProApp only
- **Basic:** ProApp + 1 module
- **Pro:** ProApp + 3 modules
- **Business:** ProApp + all 5 modules
