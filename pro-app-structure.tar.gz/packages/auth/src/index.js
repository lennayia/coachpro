// @pro/auth - Shared authentication logic
// TODO: Extract GenericAuthContext from CoachPro

export { AuthProvider } from './AuthProvider'
export { useAuth } from './useAuth'
